package com.ceva.base.common.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import org.apache.log4j.Logger;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.ceva.base.common.dto.RequestDTO;
import com.ceva.base.common.dto.ResponseDTO;
import com.ceva.base.common.utils.CevaCommonConstants;
import com.ceva.base.common.utils.DBConnector;
import com.ceva.util.DBUtils;

public class NewMerchantDAO {

	private Logger logger = Logger.getLogger(NewMerchantDAO.class);

	ResponseDTO responseDTO = null;
	JSONObject requestJSON = null;
	JSONObject responseJSON = null;

	
	public ResponseDTO getMerchantDetails(RequestDTO requestDTO) {

		Connection connection = null;
		logger.debug("Inside [NewMerchantDAO][GetMerchantDetails].. ");

		HashMap<String, Object> merchantMap = null;
		JSONObject resultJson = null;
		JSONArray merchantJsonArray = null;
		PreparedStatement merchantPstmt = null;
		ResultSet merchantRS = null;

		JSONObject json = null;

		String merchantQry = "Select MERCHANT_ID,MERCHANT_NAME,"
				+ "Decode(STATUS,'A','Active','B','Inactive','N','Un-Authorize'),"
				+ "to_char(MAKER_DTTM,'DD-MM-YYYY HH24:MI:SS') "
				+ "from MERCHANT_MASTER order by MERCHANT_ID";
		try {

			responseDTO = new ResponseDTO();

			connection = DBConnector.getConnection();
			logger.debug("connection is [" + connection + "]");

			merchantMap = new HashMap<String, Object>();
			resultJson = new JSONObject();
			merchantJsonArray = new JSONArray();

			merchantPstmt = connection.prepareStatement(merchantQry);
			merchantRS = merchantPstmt.executeQuery();

			json = new JSONObject();
			while (merchantRS.next()) {
				json.put(CevaCommonConstants.MERCHANT_ID,
						merchantRS.getString(1));
				json.put(CevaCommonConstants.MERCHANT_NAME,
						merchantRS.getString(2));
				json.put(CevaCommonConstants.STATUS, merchantRS.getString(3));
				json.put(CevaCommonConstants.MAKER_DATE,
						merchantRS.getString(4));
				merchantJsonArray.add(json);
				json.clear();
			}
			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			resultJson.put(CevaCommonConstants.MERCHANT_LIST, merchantJsonArray);
			merchantMap.put(CevaCommonConstants.MERCHANT_LIST, resultJson);
			logger.debug("EntityMap [" + merchantMap + "]");
			responseDTO.setData(merchantMap);

		} catch (Exception e) {
			logger.debug("Got Exception in GetMerchantDetails ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		} finally {

			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			DBUtils.closeConnection(connection);

			merchantMap = null;
			resultJson = null;
			merchantJsonArray = null;
		}
		return responseDTO;
	}

	
	
	public ResponseDTO getStoreDetails(RequestDTO requestDTO) {

		Connection connection = null;
		logger.debug("Inside [NewMerchantDAO][getStoreDetails].. ");
		
		HashMap<String, Object> merchantMap = null;
		JSONObject resultJson = null;
		JSONArray merchantJsonArray = null;
		PreparedStatement merchantPstmt = null;
		ResultSet merchantRS = null;

		JSONObject json = null;

		String merchantQry =  "Select SM.STORE_ID,SM.STORE_NAME,MM.MERCHANT_ID,MM.MERCHANT_NAME,"
				+ "Decode(SM.STATUS,'A','Active','B','Inactive','N','Un-Authorize'),to_char(SM.MAKER_DTTM,'DD-MM-YYYY HH24:MI:SS')"
				+ " from MERCHANT_MASTER MM,STORE_MASTER SM where SM.MERCHANT_ID=MM.MERCHANT_ID and MM.MERCHANT_ID=?  order by SM.STORE_ID";
		try {

			requestJSON = requestDTO.getRequestJSON();
			
			responseDTO = new ResponseDTO();

			connection = DBConnector.getConnection();
			logger.debug("connection is [" + connection + "]");

			merchantMap = new HashMap<String, Object>();
			resultJson = new JSONObject();
			merchantJsonArray = new JSONArray();

			merchantPstmt = connection.prepareStatement(merchantQry);
			
			merchantPstmt.setString(1, requestJSON.getString(CevaCommonConstants.MERCHANT_ID));
			
			merchantRS = merchantPstmt.executeQuery();

			
			while (merchantRS.next()) {
				json = new JSONObject();
				json.put(CevaCommonConstants.STORE_ID,
						merchantRS.getString(1));
				json.put(CevaCommonConstants.STORE_NAME,
						merchantRS.getString(2));
				json.put(CevaCommonConstants.MERCHANT_ID,
						merchantRS.getString(3));
				json.put(CevaCommonConstants.MERCHANT_NAME,
						merchantRS.getString(4));
				json.put(CevaCommonConstants.STATUS,
						merchantRS.getString(5));
				json.put(CevaCommonConstants.MAKER_DATE,
						merchantRS.getString(6));
				merchantJsonArray.add(json);
			}
			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			resultJson.put(CevaCommonConstants.STORE_LIST, merchantJsonArray);
			merchantMap.put(CevaCommonConstants.STORE_LIST, resultJson);
			logger.debug("EntityMap [" + merchantMap + "]");
			responseDTO.setData(merchantMap);

		} catch (Exception e) {
			logger.debug("Got Exception in getStoreDetails ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		} finally {

			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			DBUtils.closeConnection(connection);

			merchantMap = null;
			resultJson = null;
			merchantJsonArray = null;
		}
		return responseDTO;
	}

	public ResponseDTO getTerminalDetails(RequestDTO requestDTO) {

		Connection connection = null;
		logger.debug("Inside [NewMerchantDAO][getTerminalDetails].. ");
		
		HashMap<String, Object> merchantMap = null;
		JSONObject resultJson = null;
		JSONArray merchantJsonArray = null;
		PreparedStatement merchantPstmt = null;
		ResultSet merchantRS = null;

		JSONObject json = null;

		String merchantQry =  "Select TERMINAL_ID,STORE_ID,MERCHANT_ID,Decode(STATUS,'A','Active','B','Inactive','D','Deactive',STATUS),"
				+ "to_char(MAKER_DTTM,'DD-MM-YYYY HH24:MI:SS'),"
				+ "SERIAL_NO from TERMINAL_MASTER  where trim(STORE_ID)=trim(?)";
		try {

			requestJSON = requestDTO.getRequestJSON();
			
			responseDTO = new ResponseDTO();

			connection = DBConnector.getConnection();
			logger.debug("connection is [" + connection + "]");

			merchantMap = new HashMap<String, Object>();
			resultJson = new JSONObject();
			merchantJsonArray = new JSONArray();

			merchantPstmt = connection.prepareStatement(merchantQry);
			
			merchantPstmt.setString(1, requestJSON.getString(CevaCommonConstants.STORE_ID));
			
			merchantRS = merchantPstmt.executeQuery();

			
			while (merchantRS.next()) {
				json = new JSONObject();
				json.put(CevaCommonConstants.TERMINAL_ID,merchantRS.getString(1));
				json.put(CevaCommonConstants.STORE_ID,merchantRS.getString(2));
				json.put(CevaCommonConstants.MERCHANT_ID,merchantRS.getString(3));
				json.put(CevaCommonConstants.STATUS,merchantRS.getString(4));
				json.put(CevaCommonConstants.MAKER_DATE,merchantRS.getString(5));
				json.put("serialNo", merchantRS.getString(6));
				merchantJsonArray.add(json);
			}
			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			resultJson.put(CevaCommonConstants.TERMINAL_LIST, merchantJsonArray);
			merchantMap.put(CevaCommonConstants.TERMINAL_LIST, resultJson);
			logger.debug("EntityMap [" + merchantMap + "]");
			responseDTO.setData(merchantMap);

		} catch (Exception e) {
			logger.debug("Got Exception in getTerminalDetails ["
					+ e.getMessage() + "]");
			e.printStackTrace();
		} finally {

			DBUtils.closePreparedStatement(merchantPstmt);
			DBUtils.closeResultSet(merchantRS);
			DBUtils.closeConnection(connection);

			merchantMap = null;
			resultJson = null;
			merchantJsonArray = null;
		}
		return responseDTO;
	}

	
}
